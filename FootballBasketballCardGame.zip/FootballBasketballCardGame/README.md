Written with Java

Eclipse and Netbeans ides are recommended to run 

Image settings -> Scale and layout -> Change the size of text, application and other elements -> Select 100% before running the project
