package futbolBasketbolKartOyunu;

public class Kullanici extends Oyuncu {

    public Kullanici() {}

    public Kullanici(String oyuncuID, String oyuncuAdi, int skor) {
        super(oyuncuID, oyuncuAdi, skor);
    }
}