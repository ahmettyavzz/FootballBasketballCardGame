package futbolBasketbolKartOyunu;

public class Bilgisayar extends Oyuncu {

    public Bilgisayar() {}

    public Bilgisayar(String oyuncuID, String oyuncuAdi, int skor) {
        super(oyuncuID, oyuncuAdi, skor);
    }
}